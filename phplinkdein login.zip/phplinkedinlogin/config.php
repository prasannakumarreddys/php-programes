<?php
$baseURL = 'BASE_URL';
$callbackURL = 'CALLBACK_URL';
$linkedinApiKey = 'Client Id';
$linkedinApiSecret = 'Client Secret';
$linkedinScope = 'r_basicprofile r_emailaddress';
?>
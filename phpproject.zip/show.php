<?php
	$conn = mysql_connect("localhost","root","");
	$db      = mysql_select_db("spkr",$conn);
?>
 
<?php
 
	echo "<ul>";
	$sql = "select * from bbc";
 
	$qury = mysql_query($sql);
 
	while($row = mysql_fetch_array($qury))
		echo "<li>Name: $row[0]</li><li>phonenumber: $row[1]</li><li>workskill: $row[2]</li><li>address: $row[3]</li><br />";
 
	echo "</ul>";
 
?>
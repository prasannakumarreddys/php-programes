<?php
	$conn = mysql_connect("localhost","root","");
	$db      = mysql_select_db("spkr",$conn);
?>
 
<?php
 
	$name       =	  $_POST['user'];
	$phonenumber = 	  $_POST['phonenumber'];
        $workskill = $_POST['workskill'];
$address = $_POST['address'];


 
	# echo "My name is $name <br /> And I'm the CEO of my company {$company}"
 
	$sql     = "INSERT into bbc values('$name','$phonenumber','$workskill','$address')";
	$qury  = mysql_query($sql);
 
	if(!$qury)
		echo mysql_error();
	else
	{
		echo "Successfully Inserted<br />";
		echo "<a href='show.php'>View Result</a>";
	}
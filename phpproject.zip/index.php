<hr><strong><b><marquee><font size="6">WORKFINDER</font></marquee></b></strong></hr>
<BODY BGCOLOR="#5600123" TEXT="#FFFF00" LINK="#FF0000" VLINK="#FFFFFF" ALINK="#00FF00" BACKGROUND="path/filename" >
<hr></hr>
<hr>
<img src="2.jpg" alt="Mountain View" style="width:1800px;height:160px;">
</hr>
<hr>
</hr><?php
/*
Author: Javed Ur Rehman
Website: http://www.allphptricks.com/
*/

include("auth.php"); //include auth.php file on all secure pages ?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Welcome Home</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
<div class="form">
<p>Welcome <?php echo $_SESSION['username']; ?>!</p>
<center><a href="button.php">Categories</a></center><br>

<center><a href="logout.php">Logout</a></center><br>

<center> <a href='show.php'>home</a></center><br>
<br /><br /><br /><br />
</div>
<center><p>&copy; 2017 workfinder.com<p></center>
</body>
</html>

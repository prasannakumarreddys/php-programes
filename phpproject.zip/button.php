<hr><strong><b><marquee><font size="6">WORKFINDER</font></marquee></b></strong></hr>
<BODY BGCOLOR="#5600123" TEXT="#FFFF00" LINK="#FF0000" VLINK="#FFFFFF" ALINK="#00FF00" BACKGROUND="path/filename" >
<hr></hr>
<hr>
<img src="2.jpg" alt="Mountain View" style="width:1800px;height:160px;">
</hr>
<hr>
</hr>
<a href="postform.php"><button>electrician</button></a>
<a href="postform.php"><button>mechanic</button></a>
<a href="postform.php"><button>plumber</button></a>
<a href="postform.php"><button>driver</button></a>
<a href="postform.php"><button>tv repaire</button></a>
<a href="postform.php"><button>computer repaire</button></a>
<a href="postform.php"><button>labour</button></a>
<a href="postform.php"><button>packager</button></a>
<a href="postform.php"><button>shope keeper</button></a>

